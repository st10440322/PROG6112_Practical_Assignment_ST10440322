/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */package Assignment1prog;
import java.util.InputMismatchException;
import java.util.Scanner;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class Question1Test {
    @Before
    public void setUp() {
        // Clear the students list before each test
        Question1.students.clear();
    }

    @Test
    public void testSaveStudent_ValidInput() {
        try {
            // Create a new student and save 
            Student student1 = new Student("10111", "J Bloggs", 19, "jbloggs@ymail.com", "disd ", "password1$23");
             Student student2= new Student("10112", "J Doe", 21, "jdoe@ymail.com", "disd ", "DoeDouble24");
              Student student3 = new Student("10113", "P Parker", 20, "spidey@ymail.com", "disn ", "spiderverse");
            Question1.students.add(student1);
            Question1.students.add(student2);
            Question1.students.add(student3);
            System.out.println("Student"+student1);
            System.out.println("Student"+student2);
            System.out.println("Student"+student3);

            // Verify if the student is saved correctly
            assertEquals(3, Question1.students.size());
            assertEquals("ST123", Question1.students.get(0).id);
        } catch (Exception e) {
            fail("Saving a valid student should not throw an exception.");
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSaveStudent_InvalidAge() {
        // Test saving a student with invalid age
        new Student("ST123", "John Doe", 15, "john.doe@example.com", "Computer Science", "password123");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testSaveStudent_InvalidEmail() {
        // Test saving a student with invalid email
       Student student1 = new Student("10111", "J Bloggs", 19, "jbloggs@ymail.com", "disd ", "password1$23");
             Student student2= new Student("10112", "J Doe", 21, "jdoe@ymail.com", "disd ", "DoeDouble24");
              Student student3 = new Student("10113", "P Parker", 20, "spidey@ymail.com", "disn ", "spiderverse");
           
    }

    @Test
    public void testSearchStudent_Existing() {
        try {
            // Create a new student and save
           Student student1 = new Student("10111", "J Bloggs", 19, "jbloggs@ymail.com", "disd ", "password1$23");
             Student student2= new Student("10112", "J Doe", 21, "jdoe@ymail.com", "disd ", "DoeDouble24");
              Student student3 = new Student("10113", "P Parker", 20, "spidey@ymail.com", "disn ", "spiderverse");
            Question1.students.add(student1);
            Question1.students.add(student2);
            Question1.students.add(student3);
            System.out.println("Student"+student1);
            System.out.println("Student"+student2);
            System.out.println("Student"+student3);
            // Simulate search for the student
            String result = "";
            for (Student s : Question1.students) {
                if (s.id.equals("10111")) {
                    result = s.toString();
                    break;
                }
            }

            // Verify if the student is found
            assertFalse(result.isEmpty());
        } catch (Exception e) {
            fail("Searching for an existing student should not throw an exception.");
        }
    }

    @Test
    public void testSearchStudent_NotFound() {
        try {
            // Simulate search for a non-existent student
            String result = "10115";
            for (Student s : Question1.students) {
                if (s.id.equals("10111")) {
                    result = s.toString();
                    break;
                }
            }

            // Verify that the student is not found
            assertTrue(result.isEmpty());
        } catch (Exception e) {
            fail("Searching for a non-existent student should not throw an exception.");
        }
    }

    @Test
    public void testDeleteStudent_Existing() {
        try {
            // Create a new student and save
            Student student1 = new Student("10111", "J Bloggs", 19, "jbloggs@ymail.com", "disd ", "password1$23");
             Student student2= new Student("10112", "J Doe", 21, "jdoe@ymail.com", "disd ", "DoeDouble24");
              Student student3 = new Student("10113", "P Parker", 20, "spidey@ymail.com", "disn ", "spiderverse");
            Question1.students.add(student1);
            Question1.students.add(student2);
            Question1.students.add(student3);
            System.out.println("Student"+student1);
            System.out.println("Student"+student2);
            System.out.println("Student"+student3);
            // Simulate delete operation
            boolean deleted = false;
            for (Student s : Question1.students) {
                if (s.id.equals("10112")) {
                    Question1.students.remove(s);
                    deleted = true;
                    break;
                }
            }

            // Verify if the student is deleted
            assertTrue(deleted);
            assertEquals(3, Question1.students.size());
        } catch (Exception e) {
            fail("Deleting an existing student should not throw an exception.");
        }
    }

    @Test
    public void testDeleteStudent_NotFound() {
        try {
            // Simulate delete operation for a non-existent student
            boolean deleted = false;
            for (Student s : Question1.students) {
                if (s.id.equals("10111")) {
                    Question1.students.remove(s);
                    deleted = true;
                    break;
                }
            }

            // Verify that deletion is not performed
            assertFalse(deleted);
        } catch (Exception e) {
            fail("Attempting to delete a non-existent student should not throw an exception.");
        }
    }

    @Test
    public void testStudentAge_Valid() {
        try {
            int validAge = 20;
            assertTrue(validAge >= 16);
            System.out.println("age given"+validAge);

        } catch (Exception e) {
            fail("Valid age input should not throw an exception.");
        }
    }

    @Test
    public void testStudentAge_Invalid() {
        try {
            int invalidAge = 15;
            assertFalse(invalidAge >= 16);
            System.out.println("age given"+invalidAge);
        } catch (Exception e) {
            fail("Invalid age input should not throw an exception.");
        }
    }

    @Test(expected = InputMismatchException.class)
    public void testStudentAge_InvalidCharacter() {
        // Simulate invalid character input Please enter a number 
        Question1.scanner = new Scanner("21");
        Question1.getValidAge(); // This should throw an InputMismatchException
    }
}
