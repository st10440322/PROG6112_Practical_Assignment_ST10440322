/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Assignment1prog;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author Hp-PC
 */
public class HospitalManagementSystemTest {
    
    public HospitalManagementSystemTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of addStaff method, of class HospitalManagementSystem.
     */
    @Test
    public void testAddStaff() {
        System.out.println("addStaff");
        HospitalManagementSystem instance = new HospitalManagementSystem();
        instance.addStaff();
    }

    /**
     * Test of assignJob method, of class HospitalManagementSystem.
     */
    @Test
    public void testAssignJob() {
        System.out.println("assignJob");
        HospitalManagementSystem instance = new HospitalManagementSystem();
        instance.assignJob();
    }

    /**
     * Test of showAllStaff method, of class HospitalManagementSystem.
     */
    @Test
    public void testShowAllStaff() {
        System.out.println("showAllStaff");
        HospitalManagementSystem instance = new HospitalManagementSystem();
        instance.showAllStaff();
    }

    /**
     * Test of showAllJobs method, of class HospitalManagementSystem.
     */
    @Test
    public void testShowAllJobs() {
        System.out.println("showAllJobs");
        HospitalManagementSystem instance = new HospitalManagementSystem();
        instance.showAllJobs();
    }

    /**
     * Test of payStaff method, of class HospitalManagementSystem.
     */
    @Test
    public void testPayStaff() {
        System.out.println("payStaff");
        HospitalManagementSystem instance = new HospitalManagementSystem();
        instance.payStaff();
    }

    /**
     * Test of main method, of class HospitalManagementSystem.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        HospitalManagementSystem.main(args);
    }
    
}
