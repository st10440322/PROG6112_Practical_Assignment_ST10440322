package Assignment1prog;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author Hp-PC
 */
public class StaffTest {

    private Staff staff;

    @Before
    public void setUp() {
        // Initialize a Staff instance before each test
        staff = new StaffImpl("John Doe", 123, 5000.0);
    }

    @Test
    public void testGetName() {
        System.out.println("testGetName");
        String expResult = "John Doe";
        String result = staff.getName();
        assertEquals(expResult, result);
    }

    @Test
    public void testGetId() {
        System.out.println("testGetId");
        int expResult = 123;
        int result = staff.getId();
        assertEquals(expResult, result);
    }

    @Test
    public void testGetSalary() {
        System.out.println("testGetSalary");
        double expResult = 5000.0;
        double result = staff.getSalary();
        assertEquals(expResult, result, 0);
    }

    @Test
    public void testSetSalary() {
        System.out.println("testSetSalary");
        double newSalary = 6000.0;
        staff.setSalary(newSalary);
        double result = staff.getSalary();
        assertEquals(newSalary, result, 0);
    }

    @Test
    public void testPerformDuties() {
        System.out.println("testPerformDuties");
        // Perform any actions or assertions related to performDuties
        staff.performDuties();
    }

    @Test
    public void testDisplayInfo() {
        System.out.println("testDisplayInfo");
               staff.displayInfo();
       
    }

    public class StaffImpl extends Staff {
        public StaffImpl(String name, int id, double salary) {
            super(name, id, salary);
        }

        @Override
        public void performDuties() {
        }
    }
}
