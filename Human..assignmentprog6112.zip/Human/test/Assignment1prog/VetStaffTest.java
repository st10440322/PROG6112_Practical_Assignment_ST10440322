/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
*/ package Assignment1prog;

import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;

/**
 *
 * @author Hp-PC
 */
public class VetStaffTest {

    private VetStaff vetStaff;

    @Before
    public void setUp() {
        // Initialize VetStaff instance before each test
        vetStaff = new VetStaff("Dr. Alice", "Veterinarian");
    }

    @Test
    public void testPerformDuties_ExamineAnimals() {
        System.out.println("testPerformDuties_ExamineAnimals");
      
        String result = vetStaff.performDuties();
      
        assertEquals("Examining and treating animals.", result);
    }

    @Test
    public void testPerformDuties_Surgery() {
        System.out.println("testPerformDuties_Surgery");
       
        vetStaff.setSpecialty(" No Surgery Needed");
        String result = vetStaff.performDuties();
       
        assertEquals("Performing no surgical operations on animal.", result);
    }

    @Test
    public void testPerformDuties_Emergency() {
        System.out.println("testPerformDuties_Emergency");
        // Perform the duties that involve handling emergency cases
        vetStaff.setSpecialty("Emergency ( ran into a dam)");
        String result = vetStaff.performDuties();
      
        assertEquals("Handling emergency cases and critical care.", result);
    }

    @Test
    public void testPerformDuties_UnknownSpecialty() {
        System.out.println("testPerformDuties_UnknownSpecialty");
        // Perform the duties with an unknown specialty or default behavior
        vetStaff.setSpecialty("wolf dog");
        String result = vetStaff.performDuties();
     
        assertEquals("General veterinary duties.", result);
    }

    //  VetStaff has a constructor and a setSpecialty method
    public class VetStaff {
        private String name;
        private String specialty;

        public VetStaff(String name, String specialty) {
            this.name = name;
            this.specialty = specialty;
        }

        public void setSpecialty(String specialty) {
            this.specialty = specialty;
        }

        public String performDuties() {
            return switch (specialty) {
                case "Surgery" -> "Performing surgical operations on animals.";
                case "Emergency" -> "Handling emergency cases and critical care.";
                default -> "Examining and treating animals.";
            };
        }
    }
}
