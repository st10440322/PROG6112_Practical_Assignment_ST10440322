/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package Assignment1prog;
//package Assignment1prog;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Base class for all staff members
abstract class Staff {
    public String name;
    public int id;
    public double salary;

    public Staff(String name, int id, double salary) {
        this.name = name;
        this.id = id;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public abstract void performDuties();

    public void displayInfo() {
        System.out.println("Name: " + name + ", ID: " + id + ", Salary: " + salary);
    }
}

// Hospital staff
class HospitalStaff extends Staff {
    public HospitalStaff(String name, int id, double salary) {
        super(name, id, salary);
    }

    @Override
    public void performDuties() {
        System.out.println(getName() + " is performing hospital duties.");
    }
}

// Veterinary staff
class VetStaff extends Staff {
    public VetStaff(String name, int id, double salary) {
        super(name, id, salary);
    }

    @Override
    public void performDuties() {
        System.out.println(getName() + " is performing veterinary duties.");
    }
}

// Class representing a job or task assigned to staff
class Job {
    private final String description;
    private boolean isCompleted;

    public Job(String description) {
        this.description = description;
        this.isCompleted = false;
    }

    public String getDescription() {
        return description;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void completeJob() {
        this.isCompleted = true;
    }

    @Override
    public String toString() {
        return "Job: " + description + ", Completed: " + isCompleted;
    }
}

// Class to manage payment
class Payment {
    public void processPayment(Staff staff) {
        System.out.println("Processing payment for " + staff.getName() + ": $" + staff.getSalary());
    }
}

// Main class to manage the system
public class HospitalManagementSystem {
    private List<Staff> staffList;
    private List<Job> jobList;
    private Scanner scanner;

    public HospitalManagementSystem() {
        staffList = new ArrayList<>();
        jobList = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public void addStaff() {
        System.out.print("Enter staff type (hospital/vet): ");
        String type = scanner.nextLine();

        System.out.print("Enter staff full name: ");
        String name = scanner.nextLine();

        System.out.print("Enter staff ID:( 10 numbers only) ");
        int id = Integer.parseInt(scanner.nextLine());

        System.out.print("Enter staff salary: ");
        double salary = Double.parseDouble(scanner.nextLine());

        Staff staff;
        if (type.equalsIgnoreCase("hospital")) {
            staff = new HospitalStaff(name, id, salary);
        } else {
            staff = new VetStaff(name, id, salary);
        }
        staffList.add(staff);
        System.out.println("Staff added successfully.\n");
        
    }

    public void assignJob() {
        System.out.print("Enter job description: ");
        String description = scanner.nextLine();
        Job job = new Job(description);
        jobList.add(job);
        System.out.println("Job assigned successfully.\n");
    }

    public void showAllStaff() {
        System.out.println("Hospital and Vet Staff:");
        for (Staff staff : staffList) {
            staff.displayInfo();
        }
    }

    public void showAllJobs() {
        System.out.println("Assigned Jobs:");
        for (Job job : jobList) {
            System.out.println(job);
        }
    }

    public void payStaff() {
        Payment payment = new Payment();
        for (Staff staff : staffList) {
            payment.processPayment(staff);
        }
    }

    public static void main(String[] args) {
        HospitalManagementSystem system = new HospitalManagementSystem();
        Scanner scanner = new Scanner(System.in);
        String choice;

        do {
            System.out.println("1. Add Staff");
            System.out.println("2. Assign Job");
            System.out.println("3. Show All Staff");
            System.out.println("4. Show All Jobs");
            System.out.println("5. Pay Staff");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    system.addStaff();
                    break;
                case "2":
                    system.assignJob();
                    break;
                case "3":
                    system.showAllStaff();
                    break;
                case "4":
                    system.showAllJobs();
                    break;
                case "5":
                    system.payStaff();
                    break;
                case "6":
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (!choice.equals("6"));
    }
}
