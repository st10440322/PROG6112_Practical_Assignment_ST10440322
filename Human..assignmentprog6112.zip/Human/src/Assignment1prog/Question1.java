package Assignment1prog;

import java.io.*;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

// Class representing a Student, implementing Serializable to allow object serialization
class Student implements Serializable {
    public String id;
    public String name;
    public int age;
    public String email;
    public String course;
    public String password; // Added password field

    // Constructor to initialize a Student object
    public Student(String id, String name, int age, String email, String course, String password) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.course = course;
        this.password = password; // Initialize password
    }

    // Override toString method to print student information
    @Override
    public String toString() {
        return "ID: " + id + "\nName: " + name + "\nAge: " + age + "\nEmail: " + email + "\nCourse: " + course;
    }
}

public class Question1 {
    public static ArrayList<Student> students = new ArrayList<>(); // List to store students
    public static final String FILE_PATH = "students.dat"; // File path to save students data
    public static Scanner scanner = new Scanner(System.in); // Scanner for input

    public static void main(String[] args) {
        loadStudentsFromFile(); // Load existing students from file
        int choice;
        do {
            choice = showMenu(); // Display menu and get user's choice
            switch (choice) {
                case 1 -> saveStudent(); // Capture new student
                case 2 -> searchStudent(); // Search for a student
                case 3 -> deleteStudent(); // Delete a student
                case 4 -> updateStudent(); // Update student information
                case 5 -> printStudentReport(); // Print report of all students
                case 6 -> {
                    System.out.println("Exiting student application...");
                    saveStudentsToFile(); // Save students to file before exiting
                }
                default -> System.out.println("Invalid choice. Try again."); // Handle invalid menu choice
            }
        } while (choice != 6); // Continue until user chooses to exit
    }

    // Method to display the menu and get user's choice
    public static int showMenu() {
        System.out.println("\n1. Capture New Student");
        System.out.println("2. Search Student");
        System.out.println("3. Delete Student");
        System.out.println("4. Update Student Information");
        System.out.println("5. Print Report");
        System.out.println("6. Exit");
        System.out.print("Enter your choice: ");
        return getIntInput(); // Get and return the user's choice
    }

    // Method to capture a new student
    public static void saveStudent() {
        scanner.nextLine(); // Consume newline left from previous input
        String id = getUniqueID(); // Get a unique ID for the student
        String name = getStringInput("Enter Name (Full name and surname): "); // Get student name
        int age = getValidAge(); // Get valid age (16 or older)
        String email = getStringInput("Enter Email (Student email only): "); // Get student email
        scanner.nextLine(); // Consume newline
        String course = getStringInput("Enter Course: "); // Get student course
        String password = getValidPassword(); // Get a valid password (unique and doesn't contain '@')

        // Add the new student to the list
        students.add(new Student(id, name, age, email, course, password));
        System.out.println("Student added successfully.");
        saveStudentsToFile(); // Save students list to file
    }

    // Method to search for a student by ID
    public static void searchStudent() {
        scanner.nextLine(); // Consume newline
        String id = getStringInput("Enter student ID to search: "); // Get ID to search for
        for (Student student : students) {
            if (student.id.equals(id)) { // Check if the student exists
                System.out.println("Student found:\n" + student); // Display student details
                return;
            }
        }
        System.out.println("Student not found. Please try again."); // Student not found
    }

    // Method to delete a student by ID
    public static void deleteStudent() {
        scanner.nextLine(); // Consume newline
        String id = getStringInput("Enter student ID to delete: "); // Get ID to delete
        for (Student student : students) {
            if (student.id.equals(id)) { // Check if the student exists
                students.remove(student); // Remove student from list
                System.out.println("Student deleted successfully.");
                saveStudentsToFile(); // Save the updated list to file
                return;
            }
        }
        System.out.println("Student not found."); // Student not found
    }

    // Method to update a student's information
    public static void updateStudent() {
        scanner.nextLine(); // Consume newline
        String id = getStringInput("Enter student ID to update: "); // Get ID to update
        for (Student student : students) {
            if (student.id.equals(id)) { // Check if the student exists
                UpdateStudentInfo(student); // Update the student's information
                saveStudentsToFile(); // Save the updated list to file
                return;
            }
        }
        System.out.println("Student not found."); // Student not found
    }

    // Method to update student information fields
    public static void UpdateStudentInfo(Student student) {
        String newName = getStringInput("Enter new Name (leave blank to keep current): ");
        if (!newName.isEmpty()) student.name = newName; // Update name if provided

        int newAge = getValidAge();
        if (newAge >= 16) student.age = newAge; // Update age if valid

        String newEmail = getStringInput("Enter new Email (leave blank to keep current): ");
        if (!newEmail.isEmpty()) student.email = newEmail; // Update email if provided

        String newCourse = getStringInput("Enter new Course (leave blank to keep current): ");
        if (!newCourse.isEmpty()) student.course = newCourse; // Update course if provided

        String newPassword = getValidPassword();
        if (!newPassword.isEmpty()) student.password = newPassword; // Update password if provided

        System.out.println("Student information updated successfully.");
    }

    // Method to print a report of all students
    public static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No student(s) to display."); // No students in the list
        } else {
            System.out.println("Student List:");
            for (Student student : students) {
                System.out.println(student); // Print each student's details
                System.out.println(); // Add a line break between students
            }
        }
    }

    // Method to save students list to a file
    public static void saveStudentsToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(students); // Serialize the students list
        } catch (IOException e) {
            System.out.println("Error saving students: " + e.getMessage()); // Handle exceptions
        }
    }

    // Method to load students list from a file
    public static void loadStudentsFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_PATH))) {
            students = (ArrayList<Student>) ois.readObject(); // Deserialize the students list
        } catch (FileNotFoundException e) {
            // No previous data, which is fine.
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading students: " + e.getMessage()); // Handle exceptions
        }
    }

    // Helper method to get an integer input with error handling
    public static int getIntInput() {
        while (true) {
            try {
                return scanner.nextInt(); // Return valid integer input
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter an integer.");
                scanner.next(); // Clear the invalid input
            }
        }
    }

    // Helper method to get a string input with a prompt
    public static String getStringInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine();
    }

    // Helper method to get a valid age input (16 or older)
    public static int getValidAge() {
        int age = 0;
        while (true) {
            System.out.print("Enter Age (Must be 16 and older): ");
            age = getIntInput(); // Get integer input for age
            if (age >= 16) {
                return age; // Return valid age
            } else {
                System.out.println("Age must be at least 16."); // Handle invalid age
            }
        }
    }

    // Helper method to get a unique student ID
    public static String getUniqueID() {
        while (true) {
            String id = getStringInput("Enter ID: "); // Get ID input
            if (isIDUnique(id)) {
                return id; // Return if ID is unique
            } else {
                System.out.println("ID already exists. Please enter a unique ID."); // Handle duplicate ID
            }
        }
    }

    // Helper method to check if a student ID is unique
    public static boolean isIDUnique(String id) {
        for (Student student : students) {
            if (student.id.equals(id)) {
                return false; // Return false if ID is found
            }
        }
        return true; // Return true if ID is unique
    }

    // Helper method to get a valid password (unique and does not contain '@')
    public static String getValidPassword() {
        while (true) {
            String password = getStringInput("Enter Password (cannot contain '@'): ");
            if (password.contains("@")) {
                System.out.println("Password cannot contain '@'. Please enter a valid password."); // Handle invalid password
            } else if (!isPasswordUnique(password)) {
                System.out.println("Password already exists. Please enter a unique password."); // Handle duplicate password
            } else {
                return password; // Return valid password
            }
        }
    }

    // Helper method to check if a password is unique
    public static boolean isPasswordUnique(String password) {
        for (Student student : students) {
            if (student.password.equals(password)) {
                return false; // Return false if password is found
            }
        }
        return true; // Return true if password is unique
    }
}


//code attribution A;
// This code was sourced from W3Schools
//https://www.w3schools.com/java/java_try_catch.asp
// Author unknown
